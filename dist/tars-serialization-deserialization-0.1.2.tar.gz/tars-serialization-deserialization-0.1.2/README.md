**Library for serialization/deserialization of objects in python**  
Only built-in python 3.9 features are used